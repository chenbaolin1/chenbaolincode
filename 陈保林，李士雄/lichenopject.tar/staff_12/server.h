#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<unistd.h>
#include<sqlite3.h>
#include<signal.h>

#define DATABASE "user.db"

typedef struct{   //结构体
    char name[20]; //用户姓名
	char password[20]; //用户密码
	int age;  //用户年龄
	int phone; //手机号
	char department[10];//部门
	int salary; //工资
	int id; //未使用
    int type;//判断switch操作类型 
    char data[200];//用于传输成功或者失败的消息
}MSG;

//开局注册一个root
//int regin_root(sqlite3 *db);
//处理函数
int do_client(int acceptfd,sqlite3 *db);
//登录
int login(int acceptfd, MSG *msg,sqlite3 *db);
//注册
int regin(int acceptfd, MSG *msg,sqlite3 *db);
//修改密码函数
int modify_password(int acceptfd, MSG *msg,sqlite3 *db);
//查找函数-按姓名查找
int find(int acceptfd, MSG *msg,sqlite3 *db);
//删除函数
int delete(int acceptfd, MSG *msg,sqlite3 *db);
//修改信息函数
int modify_info(int acceptfd, MSG *msg,sqlite3 *db);
//增加函数
int root_add(int acceptfd, MSG *msg,sqlite3 *db);
//修改的回调函数
int modify_callback(void* arg,int f_num,char** f_value,char** f_name);
//查找函数-所有信息
int find_all(int acceptfd, MSG *msg,sqlite3 *db);
int findall_callback(void* arg,int f_num,char** f_value,char** f_name);
