/******************************************************************
 * Name:  			 Staff management system client
 * Data:  			 2020.8.8
 * Description:		 The client links to the server
 * Author:			 Mr chen
 * version number:   v1.0
 *
 * ****************************************************************/

#include "client.h"

/***********************************************************************
 * Main program to complete the query modification add delete function
 *
 * args: 
 * 		argv[1]: server ip
 *		argv[2]: server port number
 *
 * *********************************************************************/
int main(int argc, const char *argv[])
{
	int sockfd;
	int choose;
	int ret;
	MSG msg;

	//Command line pass reference check
	if(argc != 3){
		printf(" the parameter is wrong, please check the parameter. \n");
		return -1;
	}

	//创建socket文件描述符 Create the socket file descriptor
	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd < 0){
		printf("sockfd creation failed\n");
		return -1;
	}

	//Defines and initialize the address information structure 
	struct sockaddr_in ServerAddr;
	bzero(&ServerAddr,sizeof(ServerAddr));
	ServerAddr.sin_family      = AF_INET;
	ServerAddr.sin_addr.s_addr = inet_addr(argv[1]);
	ServerAddr.sin_port        = htons(atoi(argv[2]));

	//Initiate a link request
	if(connect(sockfd,(struct sockaddr*)&ServerAddr,
				sizeof(ServerAddr)) < 0){
		perror("The connection fails\n");
		return -1;

	}

	while(1){
		printf("*****************************************************************\n");
		printf("* 1.register          2.login              3.quit               *\n");
		printf("*****************************************************************\n");
		printf("Please choose:");

		//Get the choose and determine if it is correct
		if(1 != scanf("%d",&choose)){
			printf("Incorrect selection please select again\n");
			continue;
		}
		while(getchar() != '\n'){}
		//Process according to user selection
		switch(choose){

		case 1:
			Do_Register(sockfd,&msg);
			break;
		case 2:
			ret = Do_Login(sockfd,&msg);
			if(ret == 1){
				printf("11111\n");
				Root_Login_Select(sockfd,&msg);
			}else if(ret == 2){
				printf("22222\n");
				User_Login_Select(sockfd,&msg);
			}else{
				printf("login file\n");
			}
			break;

		case 3:
			close(sockfd);
			return 0;
			break;
		default:
			printf("Command error\n");


		}
	}
	return 0;
}
/************************************************************
 *功能：普通用户注册
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/

int Do_Register(int sockfd,MSG *msg)
{
	size_t ret;
	msg->type = 2;
	printf("Input name[s]:");
	scanf("%s",msg->name);
	getchar();
	printf("Input password[s]:");
	scanf("%s",msg->password);
	getchar();

	printf("Input age(int):");
	scanf("%d",&msg->age);
	getchar();

	printf("Input phone(int):");
	scanf("%d",&msg->phone);
	getchar();

	printf("Input department[s]:");
	scanf("%s",msg->department);
	getchar();

	printf("Input salary(int):");
	scanf("%d",&msg->salary);
	getchar();

	ret = send(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}
	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;

		if(ret = 0){

			printf("Server down");
			return ret;
		}
	}
	if(strncmp(msg->data, "Ok", 3) == 0)
	{
		printf("Login ok!\n");
	}
	else 
	{
		printf("注册%s\n", msg->data);
	}

	return 0;

}

/************************************************************
 *功能：用户登录函数
 *参数：套接子文件描述符，通信结构体
 *返回值：root用户返回1，user用户返回2，出错返回错误码
 * *********************************************************/
int Do_Login(int sockfd,MSG *msg)
{
	size_t ret;
	msg->type = 1;


	printf("Input name:");
	scanf("%s",msg->name);
	getchar();
	printf("Input password:");
	scanf("%s",msg->password);
	getchar();

	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret == 0){
		printf("Send buffer full\n");
		return ret;
	}

	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;
	}
	if(ret == 0){
		printf("Server down");
		return ret;
	}


	if(strncmp(msg->data, "root",5) == 0)
	{
		printf("Root login ok!\n");
		return 1;
	}
	else if(strncmp(msg->data, "user",5) == 0)
	{
		printf("user login ok!\n");
		return 2;
	}else{

		printf("%s\n", msg->data);
	}
	return 0;
}


/************************************************************
 *功能：root用户登录登录选择界面
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int Root_Login_Select(int sockfd,MSG *msg)
{
	int choose = -1;
	while(1){
		printf("**************************************************************\n");
		printf("* 1.add user  2.  delete user 3.Query user information       *\n");
		printf("* 4.Modify user information 5.exit                           *\n");
		printf("**************************************************************\n");
		printf("Please choose:");
		if(1 != scanf("%d",&choose)){
			printf("Incorrect selection please select again\n");
			continue;
		}
		while(getchar() != '\n'){}
		switch(choose){
		case 1:
			Add_User(sockfd,msg);
			break;
		case 2:
			Delete_User(sockfd,msg);
			break;
		case 3:
			Query_User_Select(sockfd,msg);
			break;
		case 4:
			modify_user(sockfd,msg);
			break;
		case 5:
			return 0;
			break;
		default:	
			printf("Command error\n");

		}

	}
	return 0;
}


/************************************************************
 *功能：普通用户登录选择界面
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int User_Login_Select(int sockfd, MSG *msg)
{
	int choose = -1;
	while(1)
	{
		printf("********************************************************\n");
		printf("* 1.Search personal information   2.Change the password*\n");
		printf("* 3.Modify basic information      4.quit               *\n");
		printf("********************************************************\n");
		printf("Please choose:");
		if(1 != scanf("%d",&choose)){
			puts("***输入错误重新输入");
			continue;
		}
		while(getchar() != '\n'){}

		switch(choose){
		case 1:
			Query_Self_Msg(sockfd,msg);
			break;
		case 2:
			Change_Password(sockfd,msg);
			break;
		case 3:
			Modify_Self_Msg(sockfd,msg);
			break;
		case 4:
			return 0;
			break;
		default :	
			printf("Command error\n");

		}

	}
	return 0;
}

/************************************************************
 *功能：root用户添加user信息
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int Add_User(int sockfd,MSG *msg)
{
	size_t ret;
	msg->type = 7;

	printf("Input name(s):");
	scanf("%s",msg->name);
	getchar();

	printf("Input password(s):");
	scanf("%s",msg->password);
	getchar();

	printf("Input age(int):");
	scanf("%d",&msg->age);
	getchar();

	printf("Input phone(int):");
	scanf("%d",&msg->phone);
	getchar();

	printf("Input department:");
	scanf("%s",msg->department);
	getchar();

	printf("Input salary:");
	scanf("%d",&msg->salary);
	getchar();


	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}
	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;
	}
	if(ret = 0){
		printf("Server down");
		return ret;
	}
	if(strncmp(msg->data, "rootadd", 8) == 0)
	{
		printf("Root add ok!\n");
		return 1;
	}else{

		printf("%s\n", msg->data);
	}

	return 0;
}

/************************************************************
 *功能：user用户删除函数
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int Delete_User(int sockfd, MSG *msg)
{
	size_t ret;
	msg->type = 5;
	printf("Please enter the user name:");
	scanf("%s",msg->name);
	getchar();

	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}

	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;
	}
	if(ret = 0){
		printf("Server down");
		return ret;
	}

	if(strncmp(msg->data, "rootdl", 7) == 0)
	{
		printf("Root delay ok!\n");
		return 0;
	}else{

		printf("%s\n", msg->data);
	}

	return 0;


}

/************************************************************
 *功能：root用户更改user用户信息
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int modify_user(int sockfd, MSG *msg)
{
	size_t ret;
	msg->type = 4;
	printf("Please enter the user name that you want to change\n");
	printf("Input name");
	scanf("%s",msg->name);
	getchar();

	printf("To modify, enter target. To do not modify, enter # \n");
	printf("Input password(s)");
	scanf("%s",msg->password);
	getchar();

	printf("To modify, enter target. To do not modify, enter 1 \n");
	printf("Input age(int):");
	scanf("%d",&msg->age);
	getchar();

	printf("To modify, enter target. To do not modify, enter 1 \n");
	printf("Input phone(int):");
	scanf("%d",&msg->phone);
	getchar();

	printf("To modify, enter target. To do not modify, enter # \n");
	printf("Input department(s):");
	scanf("%s",msg->department);
	getchar();

	printf("To modify, enter target. To do not modify, enter 1 \n");
	printf("Input salary(int):");
	scanf("%d",&msg->salary);
	getchar();


	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}

	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;
	}
	if(ret = 0){
		printf("Server down");
		return ret;
	}

	if(strncmp(msg->data, "modifyu", 8) == 0)
	{
		printf("Root Modify ok!\n");

	}else{

		printf("%s\n", msg->data);
	}
	printf("name:%s\npassword:%s\nage:%d\nphone:%d   \n",
			msg->name,msg->password,msg->age,msg->phone);
	printf("department:%s\nsalary:%d\n",
			msg->department,msg->salary);
	return 0;
}

/************************************************************
 *功能：root查询user用户信息选择界面
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int Query_User_Select(int sockfd,MSG *msg)
{

	int choose = -1;
	while(1){
		printf("**************************************************************\n");
		printf("* 1.To view a  2check out all   3.return to the previous menu*\n");
		printf("**************************************************************\n");
		printf("Please choose:");
		if(1 != scanf("%d",&choose)){
			printf("Incorrect selection please select again\n");
			continue;
		}
		while(getchar() != '\n'){}

		switch(choose){
		case 1:
			Query_One(sockfd,msg);
			break;
		case 2:
			Query_All(sockfd,msg);
			break;
		case 3:
			return 0;
			break;

		default:
			printf("Command error\n");
		}
	}
	return 0;
}



/************************************************************
 *功能：root查询单个用户信息
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int Query_One(int sockfd,MSG *msg)
{
	size_t ret;
	msg->type = 6;

	printf("Please enter user name:");
	scanf("%s",msg->name);

	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}


	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;
	}
	if(ret = 0){
		printf("Server down");
		return ret;
	}
	if(strncmp(msg->data, "nofind",7) == 0)
	{
		printf("%s\n",msg->data);

	}else{
		printf("name:%s\npassword:%s\nage:%d\nphone:%d   \n",
				msg->name,msg->password,msg->age,msg->phone);
		printf("department:%s\nsalary:%d\n",
				msg->department,msg->salary);

	}
	return 0;

}

/************************************************************
 *功能：root查询全部信息函数
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回出错信息
 * *********************************************************/
int Query_All(int sockfd,MSG *msg)
{
	int n = 1;
	size_t ret;
	msg->type = 8;

	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}

	while(1){
		ret = recv(sockfd,msg,sizeof(MSG),0);
		if(ret < 0){
			printf("Fail from recv\n");
			return ret;
		}
		if(ret = 0){
			printf("Server down");
			return ret;
		}
		if(strncmp(msg->data,"end",4) == 0){
			break;
		}
		printf("**************%d*********************\n",n);
		printf("name:%s\npassword:%s\nage:%d\nphone:%d   \n",
				msg->name,msg->password,msg->age,msg->phone);
		printf("department:%s\nsalary:%d\n",
				msg->department,msg->salary);
		n++;
	}
	return 0;
}



/************************************************************
 *功能：user查询自己信息
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int Query_Self_Msg(int sockfd,MSG *msg)
{
	size_t ret;
	msg->type = 9;

	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}


	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;
	}
	if(ret = 0){
		printf("Server down");
		return ret;
	}
	printf("name:%s\npassword:%s\nage:%d\nphone:%d   \n",
			msg->name,msg->password,msg->age,msg->phone);
	printf("department:%s\nsalary:%d\n",
			msg->department,msg->salary);
	return 0;

}


/************************************************************
 *功能：user修改密码
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int Change_Password(int sockfd, MSG *msg)
{
	size_t ret;
	msg->type = 3;
	printf("The original user name");
	scanf("%s",msg->name);
	getchar();

	printf("please input mew password");
	scanf("%s",msg->password);
	getchar();


	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}

	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;
	}
	if(ret = 0){
		printf("Server down");
		return ret;
	}	

	if(strncmp(msg->data, "pok", 4) == 0)
	{
		printf("Check password ok!\n");
		return 1;
	}else{

		printf("%s\n", msg->data);
		return 0;	
	}
	return 0;
}

/************************************************************
 *功能：普通用户修改基本信息
 *参数：套接子文件描述符，通信结构体
 *返回值：正常执行完成正常返回0，失败返回错误码
 * *********************************************************/
int Modify_Self_Msg(int sockfd,MSG *msg)
{


	size_t ret;
	msg->type = 10;
	printf("To modify, enter target. To do not modify, enter 1 \n");
	printf("Input age(int):");
	scanf("%d",&msg->age);
	getchar();

	printf("To modify, enter target. To do not modify, enter 1 \n");
	printf("Input phone(int):");
	scanf("%d",&msg->phone);
	getchar();

	strcmp(msg->department,"#");
	strcmp(msg->password,"#");
	msg->salary = 1;


	ret = send(sockfd,msg,sizeof(MSG),0);	
	if(ret < 0){
		printf("Fail to send.\n");
		return ret;
	}
	if(ret = 0){
		printf("Send buffer full\n");
		return ret;
	}

	ret = recv(sockfd,msg,sizeof(MSG),0);
	if(ret < 0){
		printf("Fail from recv\n");
		return ret;
	}
	if(ret = 0){
		printf("Server down");
		return ret;
	}

	if(strncmp(msg->data, "modifyu", 8) == 0)
	{
		printf("User Modify ok!\n");

	}else{

		printf("%s\n", msg->data);
	}
	printf("name:%s\npassword:%s\nage:%d\nphone:%d   \n",
			msg->name,msg->password,msg->age,msg->phone);
	printf("department:%s\nsalary:%d\n",
			msg->department,msg->salary);
	return 0;
}

