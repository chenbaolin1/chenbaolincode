/**********************************
 *  文件名称:   sever.c
 *  描述:       1.IP port检测
 *              2.数据库打开或创建    
 *              3.创建tcp服务端 
 *              4.服务器连接
 *              5.root和普通用户的增删改查
 ***********************************/
#include"server.h"

int main(int argc, const char *argv[])
{
	sqlite3 * db;  //数据库
	char *errmsg;   //数据库错误信息
	int sockfd;   //服务端套接字
	int acceptfd;  //接收到的套接字
	struct sockaddr_in serveraddr; 
	pid_t pid;
	char sql[200];


	//输入检测
	if(argc != 3)
	{
		printf("Usag:%s serverip port\n",argv[0]);
		return -1;
	}

	//打开数据库
	if(sqlite3_open(DATABASE,&db) != SQLITE_OK)
	{
		printf("%s\n",sqlite3_errmsg(db));
		return -1;
	}
	else
	{
		printf("open database success!!\n");
	}


	//创建信息表
	sqlite3_exec(db,"create table data_info (name text primary key, password text, age text, phone text,department text,salary text);",
			NULL,NULL,&errmsg);



	//创建套接字
	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("fail to socket.\n");
		return -1;
	}

	//优化允许绑定地址快速重用
	int b_reuse = 1;
	setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&b_reuse,sizeof(int));

	//填充sockaddr_in结构体
	bzero(&serveraddr,sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = inet_addr(argv[1]);
	serveraddr.sin_port = htons(atoi(argv[2]));

	//绑定
	if(bind(sockfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr)) < 0)
	{
		perror("fail to bind");
		return -1;
	}

	//监听
	if(listen(sockfd,5) < 0)
	{
		printf("fail to listen\n");
		return -1;
	}

	//处理僵尸进程
	signal(SIGCHLD,SIG_IGN);

	//并发服务器 
	while(1)
	{
		//接收客户端请求
		if((acceptfd = accept(sockfd,NULL,NULL)) < 0)
		{
			perror("fail to accept");
			return -1;
		}

		//创建子进程
		if((pid = fork()) < 0)
		{
			perror("fail to fork");
			return -1;
		}
		else if(pid == 0)//子进程执行操作
		{
			close(sockfd);
			do_client(acceptfd,db);
		}
		else //父进程等待接收客户端请求
		{
			close(acceptfd);
		}       
	}
	return 0;
}


/**********************************
 *处理客户端的所有请求
 ***********************************/

int do_client(int acceptfd,sqlite3 *db)
{
	MSG msg;

	while(recv(acceptfd , &msg, sizeof(MSG),0) > 0)
	{  
		printf("type:%d\n",msg.type);
		switch(msg.type)
		{
		case 1: //登陆
			login(acceptfd,&msg,db);
			break;
		case 2://普通用户注册用户
			regin(acceptfd,&msg,db);
			break;
		case 3://修改用户密码
			modify_password(acceptfd,&msg,db);
			break;
		case 4://修改用户信息
			modify_info(acceptfd,&msg,db);
			break;
		case 5://删除用户
			delete(acceptfd,&msg,db);
		case 6://查找用户
			find(acceptfd,&msg,db);
			break; 
		case 7://root增加用户
			root_add(acceptfd,&msg,db);
			break;
		case 8:  //查找所有用户
			find_all(acceptfd, &msg,db);
			break;
		case 9: //用户查询信息
			find(acceptfd,&msg,db);
			break;
		case 10: //用户更改自己的信息
			modify_info(acceptfd,&msg,db);
			break;
		default:
			printf("Invalid data msg.\n");
		}
	}

	printf("client exit.\n");
	close(acceptfd);
	exit(0);

	return 0;
}

/**********************************
 *登陆函数 msg = 1
 ***********************************/
int login(int acceptfd, MSG *msg,sqlite3 *db)
{
	int nrow;
	int ncloumn;
	char sql[128];
	char *errmsg;
	char **resultp;
	const char *i = "chigua";
	const char *j = "123";

	//判断登录的帐号密码是不是管理员
	if((strcmp(i,msg->name) == 0) && ((strcmp(j,msg->password)) == 0))   //管理员
	{
		strcpy(msg->data,"root");
		//	printf("root login success!\n");
	}
	else
	{
		//匹配数据库表中是否存在
		sprintf(sql,"select * from data_info where name = '%s' and password = '%s';"
				,msg->name,msg->password);
		if(sqlite3_get_table(db, sql, &resultp, &nrow, &ncloumn, &errmsg) != SQLITE_OK)
		{
			printf("%s\n",errmsg);
			return -1;
		}

		//如果存在用户!这里选择通过比对结构提MSG中的姓名和密码来判断是不是管理员
		if(nrow == 1)
		{
			strcpy(msg->data,"user");
		}

		//密码表中不存在改用户
		if(nrow == 0)
		{
			strcpy(msg->data,"usr/password is wrong");
		}
	}
	//返回信息
	if(send(acceptfd,msg,sizeof(MSG),0) < 0)
	{
		perror("fail to send");
	}   

	return 0;
}

/**********************************
 *注册用户函数type =2
 ***********************************/
int regin(int acceptfd, MSG *msg,sqlite3 *db)
{
	char * errmsg;
	char sql[200];
	//添加用户详细信息 姓名，密码， 年龄， 电话，部门，工资
	sprintf(sql,"insert into data_info values('%s','%s','%d','%d','%s','%d');"
			,msg->name,msg->password,msg->age,msg->phone,msg->department,msg->salary);
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
	{
		printf("user name already exist!\n");

	}
	printf("register is success!\n");

	strcpy(msg->data,"ok");

	//将是否成功的消息返回去
	if(send(acceptfd,msg,sizeof(MSG),0) < 0)
	{
		perror("fail to send\n");
	}
	return 0;

}
/**********************************
 *管理员增加用户操作函数 type 3
 ***********************************/
int root_add(int acceptfd, MSG *msg,sqlite3 *db)
{
	char * errmsg;
	char sql[200];
	//添加用户详细信息
	sprintf(sql,"insert into data_info values('%s','%s','%d','%d','%s','%d');"
			,msg->name,msg->password,msg->age,msg->phone,msg->department,msg->salary);
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
	{
		printf("user name already exist!\n");

	}
	printf("root add user success!\n");

	strcpy(msg->data,"rootadd");

	//将是否成功的消息返回去
	if(send(acceptfd,msg,sizeof(MSG),0) < 0)
	{
		perror("fail to send\n");
	}
	return 0;
}


/**********************************
 *用户更改密码操作函数type=4
 ***********************************/
int modify_password(int acceptfd, MSG *msg,sqlite3 *db)
{
	char * errmsg;
	char sql[200];
	char **resultp;
	int nrow;
	int ncloumn;

	//根据姓名修改用户信息的密码
	sprintf(sql,"update data_info set password = %s where name = '%s' ",msg->password,msg->name);
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
	{
		printf("change failed!\n");
	}
	strcpy(msg->data,"pok");
	printf("password modify success!\n");

	//将是否成功的消息返回去
	if(send(acceptfd,msg,sizeof(MSG),0) < 0)
	{
		perror("fail to send");
	}
	return 0;
}

/**********************************
 *管理员查询信息函数-按姓名查询单条type = 6
 ***********************************/
int find(int acceptfd, MSG *msg,sqlite3 *db)
{
	char sql[200] = {};
	char *errmsg;
	char **resultp;
	int nrow;
	int ncloum;
	int i;

	MSG recvMsg;
	//根据姓名搜索该用户信息
	sprintf(sql,"select *from data_info where name = '%s' ",msg->name);
	if(sqlite3_get_table(db,sql,&resultp,&nrow,&ncloum,&errmsg) != SQLITE_OK)
	{
		printf("%s\n",errmsg);
	}
	//显示相关的信息
	if(nrow == 1){
		i = ncloum;
		strcpy(recvMsg.name, resultp[i]);
		strcpy(recvMsg.password, resultp[i+1]);
		strcpy(recvMsg.department, resultp[i+4]);
		recvMsg.age = atoi(resultp[i+2]);
		recvMsg.phone = atoi(resultp[i+3]);                                                                                                                                                     
		recvMsg.salary = atoi(resultp[i+5]);
	}else{
		strcpy(recvMsg.data,"nofind");
		printf("nofind\n");
	}
	//将是否成功的消息返回去
	if(send(acceptfd,&recvMsg,sizeof(MSG),0) < 0)
	{
		perror("fail to send");
	}
	return 0;
}
/**********************************
 *管理员查询所有信息函数-查询所有信息 type =8
 ***********************************/
int find_all(int acceptfd, MSG *msg,sqlite3 *db)
{
	char sql[200] = {};
	char *errmsg;

	//查询所有信息 利用回调函数，打印所有信息
	sprintf(sql,"select *from data_info ");
	if(sqlite3_exec(db,sql,findall_callback,(void* )&acceptfd,&errmsg) != SQLITE_OK)
	{
		printf("%s\n",errmsg);
	}
	else
	{
		printf("success!\n");

	}
	strcpy(msg->data,"end");
	//将是否成功的消息返回去
	if(send(acceptfd,msg,sizeof(MSG),0) < 0)
	{
		perror("fail to send");
	}
	return 0;
}

/******************************************
 *删除信息函数: type =5
 * ***************************************/
int delete(int acceptfd, MSG *msg,sqlite3 *db)
{
	int nrow;
	int ncloumn;
	char * errmsg;
	char sql[200];
	char **resultp;

	//删除数据库中所对应的表信息
	sprintf(sql,"delete from data_info where name = '%s' ",msg->name);
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
	{
		printf("delete info failed!\n");
		strcpy(msg->data,"delete info fail");

	}
	else
	{
		strcpy(msg->data,"rootdl");
		printf("delete info success!\n");
	}
	//是否成功的消息返回去
	if(send(acceptfd,msg,sizeof(MSG),0) < 0)
	{
		perror("fail to send");
	}
	return 0;
}

/**********************************
 *修改信息函数
 ***********************************/
int modify_info(int acceptfd, MSG *msg,sqlite3 *db)
{
	char * errmsg;
	char sql[200];
	char **resultp;
	int nrow;
	int ncloumn;

	//判断是否修改密码
	if(msg->password[0] != '#')
	{
		//通过姓名修改密码
		sprintf(sql,"update data_info set password = '%s' where name = '%s' ",msg->password,msg->name);
		if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
		{
			printf("modify_password is failed!\n");
		}
	}
	//判断是否修改年龄
	if(msg->age !=1 )
	{
		//通过姓名修改年龄
		sprintf(sql,"update data_info set age = '%d' where name = '%s' ",msg->age,msg->name);
		if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
		{
			printf("modify_age is  failed!\n");
		}
	}
	//判断是否修改手机号
	if(msg->phone !=1 )
	{
		//通过姓名修改手机号
		sprintf(sql,"update data_info set phone = '%d' where name = '%s' ",msg->phone,msg->name);
		if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
		{
			printf("modify_phone is  failed!\n");
		}
	}
	//判断是否修改部门
	if(msg->department[0] != '#')
	{
		//通过姓名修改部门
		sprintf(sql,"update data_info set department = '%s' where name = '%s' ",msg->department,msg->name);
		if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
		{
			printf("modify_department is  failed!\n");
		}
	}

	//判断是否修改工资
	if(msg->salary != 1)
	{
		//通过姓名修改工资
		sprintf(sql,"update data_info set salary = '%d' where name = '%s' ",msg->salary,msg->name);
		if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
		{
			printf("modify_salary is  failed!\n");
		}
	}
	//打印该条信息所有内容
	sprintf(sql,"select * from data_info where name = '%s'",msg->name);
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK)
	{
		printf("no info\n");
	}
	strcpy(msg->data,"modifyu");
	printf("modify_info is success!\n");

	//回调函数调用数据库的该条信息
	sprintf(sql, "select * from data_info where name = '%s'", msg->name);
	if(sqlite3_exec(db, sql, modify_callback,(void *)&acceptfd, &errmsg)!= SQLITE_OK)
	{
		printf("%s\n", errmsg);
	}else{
		printf("Query record done.\n");
	}
	msg->data[0] = '\0';
	//判断是否发送
	if(send(acceptfd,msg,sizeof(MSG),0) < 0)
	{
		perror("fail to send");
	}

	return 0;
}
/*************************************
 *修改回调函数
 * **********************************/

int modify_callback(void* arg,int f_num,char** f_value,char** f_name)
{
	int acceptfd;
	MSG msg;
	acceptfd = *((int *)arg);

	sprintf(msg.name, "%s", f_value[0]);
	sprintf(msg.password, "%s", f_value[1]);
	sprintf(msg.department, "%s", f_value[4]);
	msg.age = atoi(f_value[2]); 
	msg.phone = atoi(f_value[3]); 
	msg.salary = atoi(f_value[5]); 

	send(acceptfd, &msg, sizeof(MSG), 0);
	return 0;
}
/**********************************
 *查询所有信息回调函数
 **********************************/
int findall_callback(void* arg, int f_num, char** f_value, char** f_name)
{

	int acceptfd;
	MSG msg;
	acceptfd = *((int *) arg);

	sprintf(msg.name, "%s", f_value[0]);
	sprintf(msg.password, "%s", f_value[1]);
	sprintf(msg.department, "%s", f_value[4]);
	msg.age = atoi(f_value[2]); 
	msg.phone = atoi(f_value[3]); 
	msg.salary = atoi(f_value[5]); 

	send(acceptfd, &msg, sizeof(MSG), 0); 
	return 0;

}
