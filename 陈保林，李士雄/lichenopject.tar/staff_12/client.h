#ifndef __CLIENT_H__
#define __CLIENT_H__

#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<unistd.h>


typedef struct{   //结构体
	char name[20]; //用户姓名
	char password[20]; //用户密码
	int age;  //用户年龄
	int phone; //手机号
	char department[10];//部门
	int salary; //工资
	int id; //操作成功还是失败的返回信息  0成功 1失败
	int type;//判断switch操作类型 
	char data[200];//用于传输成功或者失败的消息
}MSG;

int Do_Register(int sockfd,MSG *msg);

int Do_Login(int sockfd,MSG *msg);


int Root_Login_Select(int sockfd,MSG *msg);
int User_Login_Select(int sockfd, MSG *msg);
int Add_User(int sockfd,MSG *msg);
int Delete_User(int sockfd, MSG *msg);
int modify_user(int sockfd, MSG *msg);
int Query_User_Select(int sockfd,MSG *msg);
int Query_One(int sockfd,MSG *msg);
int Query_All(int sockfd,MSG *msg);
int Query_Self_Msg(int sockfd,MSG *msg);
int Change_Password(int sockfd, MSG *msg);
int Modify_Self_Msg(int sockfd,MSG *msg);
int Query_Self_Msg(int sockfd, MSG *msg);
int Change_Password(int sockfd, MSG *msg);
int Modify_Self_Msg(int sockfd, MSG *msg);
#endif
